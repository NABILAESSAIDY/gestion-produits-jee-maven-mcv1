<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Produits – MVC1</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="navbar-brand">
        Gestion des Produits
        <small>MVC1 &middot; Servlet / JSP / JSTL</small>
    </div>
    <div class="navbar-right">
        <span>${sessionScope.utilisateur.login}</span>
        <span class="role-tag ${sessionScope.utilisateur.role == 'ADMIN' ? 'admin' : 'user'}">
            ${sessionScope.utilisateur.role}
        </span>
        <a href="${pageContext.request.contextPath}/logout" class="lien-logout">Déconnexion</a>
    </div>
</nav>

<div class="page-wrap">

    <!-- Titre -->
    <h2 class="section-titre">
        Liste des produits
        <c:if test="${not empty produitEdit}">
            <span class="badge-edition">Edition &ndash; ID ${produitEdit.idProduit}</span>
        </c:if>
        <span class="compteur" style="margin-left:8px;">(${listeProduits.size()} produit(s))</span>
    </h2>

    <!-- Messages -->
    <c:if test="${not empty erreurMessage}">
        <div class="alerte alerte-erreur">${erreurMessage}</div>
    </c:if>
    <c:if test="${not empty infoMessage}">
        <div class="alerte alerte-info">${infoMessage}</div>
    </c:if>

    <!-- FORMULAIRE AJOUT / MODIFICATION (ADMIN seulement) -->
    <c:if test="${sessionScope.utilisateur.role == 'ADMIN'}">
        <div class="bloc">
            <div class="bloc-titre">
                <c:choose>
                    <c:when test="${not empty produitEdit}">Modifier le produit</c:when>
                    <c:otherwise>Ajouter un produit</c:otherwise>
                </c:choose>
            </div>

            <form action="${pageContext.request.contextPath}/${not empty produitEdit ? 'updateProduit' : 'addProduit'}"
                  method="post">

                <c:if test="${not empty produitEdit}">
                    <input type="hidden" name="idProduit" value="${produitEdit.idProduit}" />
                </c:if>

                <div class="form-ligne">
                    <div class="form-champ">
                        <label for="nom">Nom</label>
                        <input type="text" id="nom" name="nom"
                               placeholder="ex : Laptop Dell XPS"
                               value="${produitEdit.nom}" required />
                    </div>

                    <div class="form-champ large">
                        <label for="description">Description</label>
                        <input type="text" id="description" name="description"
                               placeholder="ex : Intel i7, 16 Go RAM, 512 Go SSD"
                               value="${produitEdit.description}" required />
                    </div>

                    <div class="form-champ">
                        <label for="prix">Prix (DH)</label>
                        <input type="text" id="prix" name="prix"
                               placeholder="ex : 4999.00"
                               value="${produitEdit.prix}" required />
                    </div>

                    <div style="display:flex; gap:8px; align-items:flex-end; padding-bottom:1px;">
                        <button type="submit"
                                class="btn ${not empty produitEdit ? 'btn-enregistrer' : 'btn-ajouter'}">
                            <c:choose>
                                <c:when test="${not empty produitEdit}">Enregistrer</c:when>
                                <c:otherwise>Ajouter</c:otherwise>
                            </c:choose>
                        </button>
                        <c:if test="${not empty produitEdit}">
                            <a href="${pageContext.request.contextPath}/listProduits"
                               class="btn btn-annuler">Annuler</a>
                        </c:if>
                    </div>
                </div>
            </form>
        </div>
    </c:if>

    <!-- RECHERCHE -->
    <div class="bloc">
        <div class="bloc-titre">Recherche par ID</div>
        <form action="${pageContext.request.contextPath}/listProduits" method="get">
            <div class="form-ligne">
                <div class="form-champ" style="max-width:200px;">
                    <label for="idProduit">ID produit</label>
                    <input type="text" id="idProduit" name="idProduit"
                           placeholder="ex : 2" />
                </div>
                <div style="display:flex; gap:8px; align-items:flex-end; padding-bottom:1px;">
                    <button type="submit" class="btn btn-rechercher">Rechercher</button>
                    <a href="${pageContext.request.contextPath}/listProduits"
                       class="btn btn-annuler">Tout afficher</a>
                </div>
            </div>
        </form>
    </div>

    <!-- TABLEAU -->
    <div class="bloc" style="padding: 0; overflow:hidden;">
        <c:choose>
            <c:when test="${empty listeProduits}">
                <div class="vide">Aucun produit à afficher.</div>
            </c:when>
            <c:otherwise>
                <table>
                    <thead>
                        <tr>
                            <th class="col-id">ID</th>
                            <th>Nom</th>
                            <th>Description</th>
                            <th>Prix (DH)</th>
                            <c:if test="${sessionScope.utilisateur.role == 'ADMIN'}">
                                <th>Actions</th>
                            </c:if>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="p" items="${listeProduits}">
                            <tr class="${not empty produitEdit and produitEdit.idProduit == p.idProduit ? 'en-edition' : ''}">
                                <td class="col-id">${p.idProduit}</td>
                                <td><strong>${p.nom}</strong></td>
                                <td>${p.description}</td>
                                <td class="col-prix">
                                    <fmt:formatNumber value="${p.prix}"
                                                      type="number"
                                                      minFractionDigits="2"
                                                      maxFractionDigits="2" />
                                </td>
                                <c:if test="${sessionScope.utilisateur.role == 'ADMIN'}">
                                    <td class="col-actions">
                                        <a href="${pageContext.request.contextPath}/editProduit?id=${p.idProduit}"
                                           class="btn btn-modifier">Modifier</a>
                                        <a href="${pageContext.request.contextPath}/deleteProduit?id=${p.idProduit}"
                                           class="btn btn-supprimer"
                                           onclick="return confirm('Supprimer le produit « ${p.nom} » ?');">Supprimer</a>
                                    </td>
                                </c:if>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </c:otherwise>
        </c:choose>
    </div>

    <!-- Note lecture seule pour USER -->
    <c:if test="${sessionScope.utilisateur.role != 'ADMIN'}">
        <div class="alerte alerte-attention">
            Vous êtes connecté en mode <strong>lecture seule</strong>.
            Les modifications sont réservées aux administrateurs.
        </div>
    </c:if>

</div>

<div class="pied-page">
    Gestion des Produits MVC1 &mdash; Servlet / JSP / JSTL &mdash; ENSA Hoceima, UAE
</div>

</body>
</html>
