package filters;

import models.Utilisateur;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * FILTRE DE GESTION DES RÔLES
 *
 * Ce filtre protège les URLs réservées aux administrateurs :
 *   /addProduit, /deleteProduit, /editProduit, /updateProduit
 *
 * Si un utilisateur avec le rôle USER tente d'accéder à ces URLs,
 * il est redirigé vers une page d'erreur 403 (accès refusé).
 *
 * Ce filtre s'applique APRÈS le filtre d'authentification.
 */
public class RoleFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req   = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String uri = req.getRequestURI();
        String contextPath = req.getContextPath();
        String path = uri.substring(contextPath.length());

        // URLs réservées aux ADMIN uniquement
        boolean estActionAdmin = path.equals("/addProduit")
                              || path.equals("/deleteProduit")
                              || path.equals("/editProduit")
                              || path.equals("/updateProduit");

        if (!estActionAdmin) {
            // Pas une action admin → laisser passer
            chain.doFilter(request, response);
            return;
        }

        // Vérification du rôle dans la session
        HttpSession session = req.getSession(false);
        Utilisateur utilisateur = (session != null)
                ? (Utilisateur) session.getAttribute("utilisateur")
                : null;

        if (utilisateur != null && utilisateur.isAdmin()) {
            // ADMIN autorisé → continuer
            chain.doFilter(request, response);
        } else {
            // Accès refusé → page d'erreur 403
            req.setAttribute("erreurCode", 403);
            req.setAttribute("erreurMessage", "Accès refusé : vous n'avez pas les droits nécessaires pour effectuer cette action.");
            req.getRequestDispatcher("/WEB-INF/views/erreur.jsp").forward(req, resp);
        }
    }

    @Override
    public void destroy() {}
}
