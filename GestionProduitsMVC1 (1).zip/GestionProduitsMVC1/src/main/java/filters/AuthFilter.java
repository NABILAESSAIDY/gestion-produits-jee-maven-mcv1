package filters;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * FILTRE D'AUTHENTIFICATION
 *
 * Ce filtre intercepte TOUTES les requêtes vers l'application.
 * Il vérifie si l'utilisateur est connecté (session "utilisateur" présente).
 * Si non connecté → redirige vers la page de login.
 * Si connecté → laisse passer la requête.
 *
 * Les URLs exclues du filtrage : /login, /logout, et les ressources statiques (css).
 */
public class AuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req  = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String uri = req.getRequestURI();
        String contextPath = req.getContextPath();

        // Calcul du chemin relatif (sans le context path)
        String path = uri.substring(contextPath.length());

        // Ressources qui ne nécessitent pas d'authentification
        boolean estPublic = path.equals("/login")
                         || path.equals("/logout")
                         || path.startsWith("/css/")
                         || path.startsWith("/images/");

        if (estPublic) {
            // Laisser passer sans vérification
            chain.doFilter(request, response);
            return;
        }

        // Vérification de la session
        HttpSession session = req.getSession(false);
        boolean estConnecte = (session != null && session.getAttribute("utilisateur") != null);

        if (estConnecte) {
            chain.doFilter(request, response);
        } else {
            // Sauvegarder l'URL demandée pour rediriger après login (optionnel)
            resp.sendRedirect(contextPath + "/login");
        }
    }

    @Override
    public void destroy() {}
}
