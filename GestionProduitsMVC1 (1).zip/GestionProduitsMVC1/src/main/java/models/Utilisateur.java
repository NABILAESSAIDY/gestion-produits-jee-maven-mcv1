package models;

/**
 * Modèle représentant un utilisateur de l'application.
 * Un utilisateur possède un rôle : ADMIN ou USER.
 * - ADMIN : peut ajouter, modifier et supprimer des produits.
 * - USER  : peut uniquement consulter la liste des produits.
 */
public class Utilisateur {

    public enum Role {
        ADMIN, USER
    }

    private String login;
    private String motDePasse;
    private Role role;

    public Utilisateur(String login, String motDePasse, Role role) {
        this.login = login;
        this.motDePasse = motDePasse;
        this.role = role;
    }

    public String getLogin() { return login; }
    public String getMotDePasse() { return motDePasse; }
    public Role getRole() { return role; }

    public boolean isAdmin() {
        return Role.ADMIN.equals(this.role);
    }
}
