package services;

import models.Utilisateur;
import models.Utilisateur.Role;
import java.util.HashMap;
import java.util.Map;

/**
 * Service d'authentification.
 * Gère les utilisateurs en mémoire (simulation d'une BDD utilisateurs).
 *
 * Comptes de démonstration :
 *   admin / admin123  -> rôle ADMIN (accès complet)
 *   user  / user123   -> rôle USER  (lecture seule)
 */
public class AuthService {

    private static AuthService instance;
    private Map<String, Utilisateur> utilisateurs = new HashMap<>();

    private AuthService() {
        // Initialisation des comptes en dur (simulation)
        utilisateurs.put("admin", new Utilisateur("admin", "admin123", Role.ADMIN));
        utilisateurs.put("user",  new Utilisateur("user",  "user123",  Role.USER));
    }

    public static AuthService getInstance() {
        if (instance == null) {
            instance = new AuthService();
        }
        return instance;
    }

    /**
     * Vérifie les identifiants et retourne l'utilisateur si valide, null sinon.
     */
    public Utilisateur authentifier(String login, String motDePasse) {
        Utilisateur u = utilisateurs.get(login);
        if (u != null && u.getMotDePasse().equals(motDePasse)) {
            return u;
        }
        return null;
    }
}
