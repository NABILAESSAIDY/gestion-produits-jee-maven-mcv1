package services;

import java.util.List;
import dao.Produit;

/**
 * Interface de la couche Service (logique métier).
 * Sert d'intermédiaire entre le Controller (Servlets) et le DAO.
 */
public interface ProduitMetier {

    void addProduit(Produit p);
    void deleteProduit(Long id);
    List<Produit> getAllProduits();
    Produit getProduitById(Long id);
    void updateProduit(Produit p);
}
