package web;

import dao.Produit;
import services.ProduitMetier;
import services.ProduitMetierImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet qui charge un produit dans le formulaire pour modification.
 * GET /editProduit?id=X → pré-remplit le formulaire avec les données du produit X.
 */
public class EditProduitServlet extends HttpServlet {

    private static final ProduitMetier metier = ProduitMetierImpl.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String idParam = req.getParameter("id");

        try {
            Long id = Long.parseLong(idParam);
            Produit p = metier.getProduitById(id);

            if (p == null) {
                req.setAttribute("erreurMessage", "Produit introuvable (ID : " + id + ").");
                req.setAttribute("listeProduits", metier.getAllProduits());
                req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
                return;
            }

            req.setAttribute("produitEdit", p);
            req.setAttribute("listeProduits", metier.getAllProduits());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);

        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "ID de produit invalide.");
            req.setAttribute("listeProduits", metier.getAllProduits());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
        }
    }
}
