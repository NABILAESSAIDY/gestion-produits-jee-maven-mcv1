package web;

import dao.Produit;
import services.ProduitMetier;
import services.ProduitMetierImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet d'affichage de la liste des produits.
 * Supporte également la recherche par ID.
 *
 * GET /listProduits          → affiche tous les produits
 * GET /listProduits?idProduit=X → affiche le produit avec l'ID X
 */
public class ListProduitServlet extends HttpServlet {

    private static final ProduitMetier metier = ProduitMetierImpl.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String idParam = req.getParameter("idProduit");
        List<Produit> liste = new ArrayList<>();

        if (idParam != null && !idParam.trim().isEmpty()) {
            try {
                Long id = Long.parseLong(idParam.trim());
                Produit p = metier.getProduitById(id);
                if (p != null) {
                    liste.add(p);
                } else {
                    req.setAttribute("infoMessage", "Aucun produit trouvé avec l'ID : " + id);
                    liste = metier.getAllProduits();
                }
            } catch (NumberFormatException e) {
                req.setAttribute("erreurMessage", "L'ID doit être un nombre entier valide.");
                liste = metier.getAllProduits();
            }
        } else {
            liste = metier.getAllProduits();
        }

        req.setAttribute("listeProduits", liste);
        req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
    }
}
