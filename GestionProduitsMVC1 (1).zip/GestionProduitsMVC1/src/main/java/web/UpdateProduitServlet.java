package web;

import dao.Produit;
import services.ProduitMetier;
import services.ProduitMetierImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet de mise à jour d'un produit.
 * POST /updateProduit → reçoit le formulaire de modification, met à jour le produit.
 */
public class UpdateProduitServlet extends HttpServlet {

    private static final ProduitMetier metier = ProduitMetierImpl.getInstance();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String idStr       = req.getParameter("idProduit");
        String nom         = req.getParameter("nom");
        String description = req.getParameter("description");
        String prixStr     = req.getParameter("prix");

        // Validation
        if (nom == null || nom.trim().isEmpty()
                || description == null || description.trim().isEmpty()
                || prixStr == null || prixStr.trim().isEmpty()) {
            req.setAttribute("erreurMessage", "Tous les champs sont obligatoires.");
            req.setAttribute("listeProduits", metier.getAllProduits());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
            return;
        }

        try {
            Long id     = Long.parseLong(idStr);
            Double prix = Double.parseDouble(prixStr.trim());

            if (prix < 0) throw new NumberFormatException("Prix négatif");

            Produit p = new Produit();
            p.setIdProduit(id);
            p.setNom(nom.trim());
            p.setDescription(description.trim());
            p.setPrix(prix);

            metier.updateProduit(p);
            resp.sendRedirect(req.getContextPath() + "/listProduits");

        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "Données invalides : vérifiez l'ID et le prix.");
            req.setAttribute("listeProduits", metier.getAllProduits());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
        }
    }
}
