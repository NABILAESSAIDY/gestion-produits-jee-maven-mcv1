package web;

import services.ProduitMetier;
import services.ProduitMetierImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet de suppression d'un produit.
 * GET /deleteProduit?id=X → supprime le produit X, redirige vers la liste.
 */
public class DeleteProduitServlet extends HttpServlet {

    private static final ProduitMetier metier = ProduitMetierImpl.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String idParam = req.getParameter("id");

        try {
            Long id = Long.parseLong(idParam);
            if (metier.getProduitById(id) == null) {
                req.setAttribute("erreurMessage", "Produit introuvable (ID : " + id + ").");
                req.setAttribute("listeProduits", metier.getAllProduits());
                req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
                return;
            }
            metier.deleteProduit(id);
            resp.sendRedirect(req.getContextPath() + "/listProduits");

        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "ID de produit invalide.");
            req.setAttribute("listeProduits", metier.getAllProduits());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
        }
    }
}
