package web;

import models.Utilisateur;
import services.AuthService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Servlet de gestion de la connexion.
 *
 * GET  /login → affiche le formulaire de connexion
 * POST /login → vérifie les identifiants et crée la session
 */
public class LoginServlet extends HttpServlet {

    private AuthService authService = AuthService.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        // Si déjà connecté, rediriger directement vers la liste
        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("utilisateur") != null) {
            resp.sendRedirect(req.getContextPath() + "/listProduits");
            return;
        }
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String login      = req.getParameter("login");
        String motDePasse = req.getParameter("motDePasse");

        // Validation des champs vides
        if (login == null || login.trim().isEmpty()
                || motDePasse == null || motDePasse.trim().isEmpty()) {
            req.setAttribute("erreur", "Veuillez remplir tous les champs.");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
            return;
        }

        // Authentification
        Utilisateur utilisateur = authService.authentifier(login.trim(), motDePasse);

        if (utilisateur != null) {
            // Création de la session
            HttpSession session = req.getSession(true);
            session.setAttribute("utilisateur", utilisateur);
            session.setMaxInactiveInterval(30 * 60); // 30 minutes
            resp.sendRedirect(req.getContextPath() + "/listProduits");
        } else {
            // Identifiants invalides
            req.setAttribute("erreur", "Login ou mot de passe incorrect.");
            req.setAttribute("loginSaisi", login); // conserver le login saisi
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
        }
    }
}
