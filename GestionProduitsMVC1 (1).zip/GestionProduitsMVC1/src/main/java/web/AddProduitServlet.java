package web;

import dao.Produit;
import services.ProduitMetier;
import services.ProduitMetierImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet d'ajout d'un produit.
 * POST /addProduit → reçoit le formulaire, crée le produit, redirige vers la liste.
 */
public class AddProduitServlet extends HttpServlet {

    private static final ProduitMetier metier = ProduitMetierImpl.getInstance();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String nom         = req.getParameter("nom");
        String description = req.getParameter("description");
        String prixStr     = req.getParameter("prix");

        // Validation des champs
        if (nom == null || nom.trim().isEmpty()
                || description == null || description.trim().isEmpty()
                || prixStr == null || prixStr.trim().isEmpty()) {
            req.setAttribute("erreurMessage", "Tous les champs sont obligatoires.");
            req.setAttribute("listeProduits", metier.getAllProduits());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
            return;
        }

        try {
            Double prix = Double.parseDouble(prixStr.trim());
            if (prix < 0) {
                throw new NumberFormatException("Prix négatif");
            }
            Produit p = new Produit(nom.trim(), description.trim(), prix);
            metier.addProduit(p);
            // Redirection POST-REDIRECT-GET pour éviter la re-soumission du formulaire
            resp.sendRedirect(req.getContextPath() + "/listProduits");

        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "Le prix doit être un nombre décimal positif.");
            req.setAttribute("listeProduits", metier.getAllProduits());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, resp);
        }
    }
}
