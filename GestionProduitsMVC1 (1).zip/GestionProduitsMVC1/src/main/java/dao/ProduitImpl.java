package dao;

import java.util.ArrayList;
import java.util.List;

/**
 * Implémentation concrète de ProduitDAO utilisant une liste en mémoire.
 * Simule une base de données pour faciliter les tests sans configuration JDBC.
 */
public class ProduitImpl implements ProduitDAO {

    private List<Produit> produits = new ArrayList<>();
    private Long compteurId = 0L;

    /**
     * Initialise quelques produits de démonstration.
     * Appelée par le Service au démarrage.
     */
    public void init() {
        addProduit(new Produit("Laptop Dell XPS", "Intel Core i7, 16GB RAM, 512GB SSD", 12500.0));
        addProduit(new Produit("Souris Logitech MX", "Souris sans fil ergonomique", 450.0));
        addProduit(new Produit("Clavier Mécanique", "Switch Cherry MX Red, rétroéclairé RGB", 780.0));
        addProduit(new Produit("Écran Samsung 27\"", "4K UHD, 144Hz, dalle IPS", 3200.0));
    }

    @Override
    public void addProduit(Produit p) {
        compteurId++;
        p.setIdProduit(compteurId);
        produits.add(p);
    }

    @Override
    public void deleteProduit(Long id) {
        Produit aSupprimer = getProduitById(id);
        if (aSupprimer != null) {
            produits.remove(aSupprimer);
        }
    }

    @Override
    public Produit getProduitById(Long id) {
        for (Produit p : produits) {
            if (p.getIdProduit().equals(id)) {
                return p;
            }
        }
        return null;
    }

    @Override
    public List<Produit> getAllProduits() {
        return produits;
    }

    @Override
    public void updateProduit(Produit p) {
        for (int i = 0; i < produits.size(); i++) {
            if (produits.get(i).getIdProduit().equals(p.getIdProduit())) {
                produits.get(i).setNom(p.getNom());
                produits.get(i).setDescription(p.getDescription());
                produits.get(i).setPrix(p.getPrix());
                break;
            }
        }
    }
}
