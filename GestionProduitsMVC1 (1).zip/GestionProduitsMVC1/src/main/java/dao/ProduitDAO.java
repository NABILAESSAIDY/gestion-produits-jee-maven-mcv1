package dao;

import java.util.List;

/**
 * Interface DAO pour la gestion des produits.
 * Définit les opérations CRUD sans préciser la méthode de persistance.
 */
public interface ProduitDAO {

    void addProduit(Produit p);
    void deleteProduit(Long id);
    Produit getProduitById(Long id);
    List<Produit> getAllProduits();
    void updateProduit(Produit p);
}
